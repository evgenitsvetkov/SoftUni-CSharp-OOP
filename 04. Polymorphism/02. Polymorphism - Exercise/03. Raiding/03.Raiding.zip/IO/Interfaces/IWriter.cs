﻿

namespace Raiding.IO.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string text) => Console.WriteLine(text);
    }
}
