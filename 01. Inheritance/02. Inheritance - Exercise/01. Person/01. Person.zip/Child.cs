﻿namespace _01._Person
{
    public class Child : Person
    {
    }
}
