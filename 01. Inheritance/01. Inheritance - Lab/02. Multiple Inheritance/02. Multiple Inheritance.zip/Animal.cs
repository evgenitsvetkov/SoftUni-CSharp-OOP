﻿namespace _02._Multiple_Inheritance
{
    public class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating...");
        }
    }
}
