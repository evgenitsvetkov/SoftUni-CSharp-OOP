﻿
namespace BorderControl.Models.Interfaces
{
    public interface IIds
    {
        string Id { get; }
    }
}
