﻿
namespace BirthdayCelebrations.Models.Interfaces
{
    public interface IIds
    {
        string Id { get; }
    }
}
